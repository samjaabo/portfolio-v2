# Opening Hours Mono
Custom variable font for Opening Hours Studio  

![oh-custom-font-01](https://user-images.githubusercontent.com/9974831/236835185-d2162632-adaf-4dcb-bcf5-f8e86c3cf62f.gif)

## Features
- 3 axes ranging from dot matrix to 80s speedboat
- Created to work both on a branding level and for detailed graphics
- View it on https://openinghours.studio. All text and 3D ASCII is set with the font
- It's fun
